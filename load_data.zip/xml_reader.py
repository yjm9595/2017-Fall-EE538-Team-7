import xml.etree.ElementTree as ET
from nltk.tokenize import TweetTokenizer
import csv
import re
from nltk.tokenize.moses import MosesTokenizer


# return tokenize text input, label
def load_data(file_name='data/ABSA16_Restaurants_Train_SB1_v2.xml'):
    tokenizer = MosesTokenizer()
    tree = ET.parse(file_name)
    root = tree.getroot()
    text_list = []
    target = []
    category = []
    for sen in root.iter('sentence'):
        edited = sen.find('text').text
        edited = edited.replace("--"," ")
        edited = edited.replace("-", " - ")

        edited = tokenizer.tokenize(edited)
        text_list.append(edited)
        target_temp=[]
        category_temp=[]
        for opi in sen.iter('Opinion'):
            target_edited = opi.get('target').replace("-", " - ")
            target_temp.append(target_edited)
            category_temp.append(opi.get('category'))
        category.append(category_temp)
        target.append(target_temp)

    lable_list = []
    skip_count=0
    for token_word,target_ in zip(text_list, target):
        lable_token=[]
        temp_token=token_word
        if len(target_)==1 and target_[0]=="NULL":
            lable_token.extend(['O' for i in range(0,len(temp_token))])
        else:
            lable_token.extend(['O' for i in range(0, len(temp_token))])
            for target_word in target_:
                # target_word_list=target_word.split()
                target_word_list = tokenizer.tokenize(target_word)
                for item in target_word_list:
                    if '&apos;' in item and item != '&apos;s':
                        temp__=re.split("(&apos;)" , item)
                        edited_target=[item__ for item__ in temp__ if item__ !='']
                        target_word_list.remove(item)
                        target_word_list.extend(edited_target)
                # target word more than two token
                if len(target_word_list)>1:
                    for idx__ in range(0,len(target_word_list)):
                        if idx__==0:
                            target_idx = temp_token.index(target_word_list[0])
                            lable_token[target_idx] = "TARGET-B"
                        else:
                            target_idx = temp_token.index(target_word_list[idx__])
                            lable_token[target_idx] = "TARGET-I"
                # target word exactly one
                elif len(target_word_list)==1:
                    if target_word_list[0]!="NULL":
                        if target_word_list[0] not in temp_token:
                            skip_count+=1
                            continue
                        target_idx=temp_token.index(target_word_list[0])
                        lable_token[target_idx]="TARGET-B"
        lable_list.append(lable_token)

    return text_list,lable_list
