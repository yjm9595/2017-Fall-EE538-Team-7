import xml_reader

input_token_data_task_1_2,output_category=xml_reader.load_data_for_task_1_2('data/ABSA16_Restaurants_Train_SB1_v2.xml')
input_token_data_task_3,output_lable = xml_reader.load_data_for_task_3('data/ABSA16_Restaurants_Train_SB1_v2.xml')


print(len(input_token_data_task_1_2))
print(len(output_lable))