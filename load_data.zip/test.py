import xml_reader

input_token_data,output_lable = xml_reader.load_data('data/ABSA16_Restaurants_Train_SB1_v2.xml')

print(len(input_token_data))
print(len(output_lable))