import os

from collections import Counter
from .general_utils import get_logger
from .data_utils import get_trimmed_glove_vectors, load_vocab, \
        get_processing_word


class Config():
    def __init__(self, load=True):
        """Initialize hyperparameters and load vocabs

        Args:
            load_embeddings: (bool) if True, load embeddings into
                np array, else None

        """
        # directory for training outputs
        if not os.path.exists(self.dir_output):
            os.makedirs(self.dir_output)

        # create instance of logger
        self.logger = get_logger(self.path_log)

        # load if requested (default)


        if load:
            self.load()


    def load(self):
        """Loads vocabulary, processing functions and embeddings
        """
        # 1. vocabulary
        self.vocab_words = load_vocab(self.filename_words)
        self.vocab_tags  = load_vocab(self.filename_tags)
        self.vocab_chars = load_vocab(self.filename_chars)
        self.vocab_pos = load_vocab(self.filename_pos)
        self.vocab_capital=load_vocab(self.filename_capital)

        self.nwords     = len(self.vocab_words)
        self.nchars     = len(self.vocab_chars)
        self.ntags      = len(self.vocab_tags)
        self.npos       = len(self.vocab_pos)
        self.ncapital   = len(self.vocab_capital)

        # 2. get processing functions that map str -> id
        self.processing_word = get_processing_word(self.vocab_words,
                self.vocab_chars, self.vocab_pos, lowercase=True, chars=self.use_chars)

        self.processing_tag  = get_processing_word(self.vocab_tags,
                lowercase=False, allow_unk=False)
        self.processing_pos  = get_processing_word(self.vocab_pos,
                lowercase=False, allow_unk=False)
        self.processing_capital  = get_processing_word(vocab_capital=self.vocab_capital,
                lowercase=False, allow_unk=False)

        
        # 3. get pre-trained embeddings
        self.embeddings = (get_trimmed_glove_vectors(self.filename_trimmed)
                if self.use_pretrained else None)
        self.pos_embeddings=(get_trimmed_glove_vectors(self.filename_pos_trimmed) if self.use_pretrained_pos else None)
        self.capital_embeddings=(get_trimmed_glove_vectors(self.filename_capital_trimmed) if self.use_pretrained_capital else None)
    



    # general config
    dir_output = "results/test/"
    dir_model  = dir_output + "model.weights/"
    path_log   = dir_output + "log.txt"

    # embeddings
    dim_word = 300
    dim_char = 100


    # glove files
    filename_glove = "data/glove.6B/glove.6B.{}d.txt".format(dim_word)
    # trimmed embeddings (created from glove_filename with build_data.py)
    filename_trimmed = "data/glove.6B.{}d.trimmed.npz".format(dim_word)
    use_pretrained = True

    #pos
    file_name_pos_embeddings="data/pos_embeddings.txt"
    filename_pos_trimmed = "data/pos_embeddings.trimmed.npz"
    use_pretrained_pos = True
    file_read=open(file_name_pos_embeddings,'r')
    tag_list=[]
    count=0
    for line in file_read:
        count+=1
        splited_list=line.split(' ')
        tag_list.append(splited_list[0])
    dim_pos=count



    #capital
    filename_capital="data/capital_tag.txt"
    filename_capital_embedding="data/capital_embedding.txt"
    filename_capital_trimmed = "data/capital_embeddings.trimmed.npz"
    use_pretrained_capital=True
    dim_capital=8
    


    # dataset
    filename_dev="data/sem_eval/validate.txt"
    filename_train="data/sem_eval/train.txt"
    #for cross validation
    filename_dev1 = "data/sem_eval/validate1.txt"
    filename_train1 = "data/sem_eval/train1.txt"
    filename_dev2 = "data/sem_eval/validate2.txt"
    filename_train2 = "data/sem_eval/train2.txt"
    filename_dev3 = "data/sem_eval/validate3.txt"
    filename_train3 = "data/sem_eval/train3.txt"
    filename_dev4 = "data/sem_eval/validate4.txt"
    filename_train4 = "data/sem_eval/train4.txt"
    filename_dev5 = "data/sem_eval/validate5.txt"
    filename_train5 = "data/sem_eval/train5.txt"

    filename_test = "data/sem_eval/test.txt"




    #filename_dev = filename_test = filename_train = "data/test.txt" # test

    max_iter = None # if not None, max number of examples in Dataset

    # vocab (created from dataset with build_data.py)
    filename_words = "data/words.txt"
    filename_tags = "data/tags.txt"
    filename_chars = "data/chars.txt"
    filename_pos="data/pos.txt"
    #conversion dictionary
    vocab_words_ = load_vocab(filename_words)
    voca_id_to_word_dict={}
    for key in vocab_words_.keys():
        voca_id_to_word_dict[vocab_words_[key]]=key

    pos_to_id_dict={}
    count=0
    for key in tag_list:
        pos_to_id_dict[key]=count
        count+=1


    # training
    train_embeddings = False
    nepochs          = 30
    dropout          = 0.5
    batch_size       = 30
    lr_method        = "adam"
    lr               = 0.005
    lr_decay         = 0.9
    clip             = -1# if negative, no clipping
    nepoch_no_imprv  = 3


    # model hyperparameters
    hidden_size_char = 100 # lstm on chars
    hidden_size_lstm = 400 # lstm on word embeddings
    hidden_size_pos=100
    hidden_size_capital=50
    # NOTE: if both chars and crf, only 1.6x slower on GPU
    use_crf = True # if crf, training is 1.7x slower on CPU
    use_chars = True # if char embedding, training is 3.5x slower on CPU
    use_word_cluster=False
    use_pos=True
    use_capital=True
