This is for slot 2, semeval compatition. To see the result, run the "evaluate.ipynb" in jupyter note book.
To train the network, run the "train.ipynb."